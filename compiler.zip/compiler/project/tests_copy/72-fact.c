// ======================================================================

int fact(int n)
{
  int tmp;

  if (n <= 1)
    return 1;
  else {
    tmp = fact(n - 1);
    return n * tmp;
  }
}

void main(void)
{
  int i;
  int j;

  input i;
  j = fact(i);
  output j;
}

// ======================================================================
