// ======================================================================

int g1;
int g2_a[50];
int g3;

void fun(int a1, int a2_p[], int a3)
{
  int fun1;
  int fun2_a[100];
  int fun3;
}

void main(void)
{
  int main1;
  int main2_a[50];
  int main3;
}

// ======================================================================
